<?php $__env->startPush('style'); ?>
    <style>
        .input-wrap {
            margin-bottom:15px       }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main">

                <section class="breadcumb-section">
                    <div class="tf-container">
                        <div class="row">
                            <div class="col-lg-12 center z-index1">
                                <h1 class="title">User Register</h1>
                                <ul class="breadcumb-list flex-five">
                                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li><span>User Register</span></li>
                                </ul>
                                <img class="bcrumb-ab" src="assets/images/page/mask-bcrumb.png" alt="">
                            </div>
                        </div>

                    </div>
                </section>

                <section class="login">
                    <div class="tf-container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="login-wrap flex">
                                    <div class="image">
                                        <img src="assets/images/page/sign-up.jpg" alt="image">
                                    </div>
                                    
                                        <form action="<?php echo e(route('storeuser')); ?>" id="register" class="login-user" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="input-wrap">
                                                        <label>Name <span style="color:red">*</span></label>
                                                        <input type="text" placeholder="Enter your name" name="name">
                                                    </div>
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color:red;margin-top:-14px"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                                <div class="col-md-6">
                                                    <div class="input-wrap">
                                                        <label>Email <span style="color:red">*</span></label>
                                                        <input type="email" placeholder="Enter your email" name="email">
                                                    </div>
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color:red;margin-top:-14px"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="input-wrap">
                                                        <div class="flex-two">
                                                            <label>Password</label>
                                                        </div>
                                                        <input type="password" placeholder="Enter your password*" name="password">
                                                    </div>
                                                     <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color:red;margin-top:-14px"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                   <div class="col-lg-6">
                                                    <div class="input-wrap">
                                                        <div class="flex-two">
                                                            <label>Confirm password</label>
                                                        </div>
                                                        <input type="password" placeholder="Enter your confirm password*" name="password_confirmation">
                                                    </div>
                                                      <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color:red;margin-top:-14px"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                        <div class="col-lg-6">
                                                            <div class="input-wrap">
                                                                <div class="flex-two">
                                                                    <label>Gender</label>
                                                                </div>
                                                                <select name="gender" class="form-control">
                                                                    <option value="">Select</option>
                                                                    <option value="1">Male</option>
                                                                    <option value="2">Female</option>
                                                                    <option value="3">Other</option>
                                                                </select>
                                                    </div>

                                                </div>
                                                <div class="col-lg-6"></div>
                                                   <div class="col-lg-12 mb-40">
                                                    <div class="input-wrap-social ">
                                                        <span class="or">or</span>
                                                        <div class="flex-three">
                                                             <a href="<?php echo e(route('googleredirect')); ?>" class="login-social flex-three btn">
                                                                <img src="<?php echo e(asset('assets/images/page/gg.png')); ?>" alt="image" style="width:25px;margin-right:10px">
                                                            </a>
                                                         
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="col-lg-12 mb-30">
                                                    <button type="submit " class="btn-submit" style="width:100%">Register</button>
                                                    </div>
                                                
                                            </div>

                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="brand-logo-widget bg-1">
                    <div class="tf-container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="swiper brand-logo overflow-hidden">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                        <div class="swiper-slide">
                                            <img src="assets/images/page/brand-logo.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>


                <section class="mb--93 bg-1">
                    <div class="tf-container">
                        <div class="callt-to-action flex-two z-index3 relative">
                            <div class="callt-to-action-content flex-three">
                                <div class="image">
                                    <img src="assets/images/page/ready.png" alt="Image">
                                </div>
                                <div class="content">
                                    <h2 class="title-call">Ready to adventure and enjoy natural</h2>
                                    <p class="des">Lorem ipsum dolor sit amet, consectetur notted adipisicin</p>
                                </div>
                            </div>
                            <img src="assets/images/page/vector4.png" alt="" class="shape-ab">
                            <div class="callt-to-action-button">
                                <a href="#" class="get-call">Let,s get started</a>
                            </div>
                        </div>
                    </div>

                </section>

            </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\hotelapp\resources\views/frontend/register.blade.php ENDPATH**/ ?>