<?php $__env->startPush('style'); ?>
    <style>
 * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: "Poppins", sans-serif;
  background-color: #3d91f5;
  color: #020138;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.hide {
  display: none;
}
.container {
  background-color: #ffffff;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
}
#stepperValue {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  font-weight: bold;
  text-align: center;
  font-size: 1.2rem;
}
.steps {
  display: inline-block;
  width: 32px;
  height: 32px;
  line-height: 32px;
  border-radius: 50%;
  background-color: #c7c9f1;
  color: #ffffff;
  text-align: center;
  transition: 0.3s ease;
}
.steps.highlight {
  background: #3d91f5;
  color: #ffffff;
  font-weight: bold;
}
.form-container {
  display: none;
}
.form-container:not(.hide) {
  display: block;
}
label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
  font-size: 0.9rem;
}
input {
  width: 100%;
  padding: 0.8rem;
  border: 1px solid #dddddd;
  border-radius: 4px;
  margin-bottom: 1rem;
  font-size: 1rem;
  transition: 0.3s;
}
input:focus {
  border-color: #3d91f5;
  outline: none;
  box-shadow: 0 0 4px rgba(76, 0, 255, 0.5);
}
.btns {
  display: flex;
  justify-content: space-between;
  margin-top: 1rem;
}
.btn {
  padding: 0.8rem 1.2rem;
  border: none;
  background: #3d91f5;
  color: #ffffff;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  font-weight: bold;
  transition: 0.3 ease;
}
.btn:hover {
  background: #3d91f5;
}
.btn:disabled {
  background: #dddddd;
  cursor: not-allowed;
}
.btn.hide {
  display: none;
}
#error-message {
  color: #e92828;
  font-size: 0.9rem;
  margin-top: 1rem;
  text-align: center;
}
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
      <main id="main">
        <div id="qbox-container">
                    <form class="needs-validation" id="form-wrapper" method="post" name="form-wrapper" novalidate="">
                        <div id="steps-container">
                            <div class="step">
                                <h4>Have you recently been in close contact with someone who has COVID-19?</h4>
                                <div class="form-check ps-0 q-box">
                                    <div class="q-box__question">
                                        <input class="form-check-input question__input" id="q_1_yes" name="q_1" type="radio" value="Yes"> 
                                        <label class="form-check-label question__label" for="q_1_yes">Yes</label>
                                    </div>
                                    <div class="q-box__question">
                                        <input checked class="form-check-input question__input" id="q_1_no" name="q_1" type="radio" value="No"> 
                                        <label class="form-check-label question__label" for="q_1_no">No</label>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <h4>Are you experiencing a high fever, dry cough, tiredness and loss of taste or smell?</h4>
                                <div class="form-check ps-0 q-box">
                                    <div class="q-box__question">
                                        <input class="form-check-input question__input" id="q_2_yes" name="q_2" type="radio" value="Yes"> 
                                        <label class="form-check-label question__label" for="q_2_yes">Yes</label>
                                    </div>
                                    <div class="q-box__question">
                                        <input checked class="form-check-input question__input" id="q_2_no" name="q_2" type="radio" value="No"> 
                                        <label class="form-check-label question__label" for="q_2_no">No</label>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <h4>Are you having diarrhoea, stomach pain, conjunctivitis, vomiting and headache?</h4>
                                <div class="form-check ps-0 q-box">
                                    <div class="q-box__question">
                                        <input class="form-check-input question__input" id="q_3_yes" name="q_3" type="radio" value="Yes"> 
                                        <label class="form-check-label question__label" for="q_3_yes">Yes</label>
                                    </div>
                                    <div class="q-box__question">
                                        <input checked class="form-check-input question__input" id="q_3_no" name="q_3" type="radio" value="No"> 
                                        <label class="form-check-label question__label" for="q_3_no">No</label>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <h4>Have you traveled to any of these countries with the highest number of COVID-19 cases in the world for the past 2 weeks?</h4>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input q-checkbox" id="q_4_uk" name="q_4" type="checkbox" value="uk"> 
                                                <label class="form-check-label question__label" for="q_4_uk">UK</label>
                                            </div>
                                        </div>
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_us" name="q_4" type="checkbox" value="us"> 
                                                <label class="form-check-label question__label" for="q_4_us">US</label>
                                            </div>
                                        </div>
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_br" name="q_3" type="checkbox" value="br"> 
                                                <label class="form-check-label question__label" for="q_4_br">Brazil</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_de" name="q_4" type="checkbox" value="de"> 
                                                <label class="form-check-label question__label" for="q_4_de">Germany</label>
                                            </div>
                                        </div>
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_in" name="q_4" type="checkbox" value="in"> 
                                                <label class="form-check-label question__label" for="q_4_in">India</label>
                                            </div>
                                        </div>
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_eu" name="q_4" type="checkbox" value="eu"> 
                                                <label class="form-check-label question__label" for="q_4_eu">Europe</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-check ps-0 q-box">
                                            <div class="q-box__question">
                                                <input class="form-check-input question__input" id="q_4_none" name="q_4" type="checkbox" value="none"> 
                                                <label class="form-check-label question__label" for="q_4_none">I did not travelled to any of these countries</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <h4>Are you experiencing any of these serious symptoms of COVID-19 below?</h4>
                                <div class="row">
                                    <div class="form-check ps-0 q-box">
                                        <div class="q-box__question">
                                            <input class="form-check-input question__input" id="q_5_breathing" name="q_5_breathing" type="checkbox" value="breathing"> 
                                            <label class="form-check-label question__label" for="q_5_breathing">Difficulty breathing or shortness of breath</label>
                                        </div>
                                    </div>
                                    <div class="form-check ps-0 q-box">
                                        <div class="q-box__question">
                                            <input class="form-check-input question__input" id="q_5_chest" name="q_5_chest" type="checkbox" value="chest pain"> 
                                            <label class="form-check-label question__label" for="q_5_chest">Chest pain or pressure</label>
                                        </div>
                                    </div>
                                    <div class="form-check ps-0 q-box">
                                        <div class="q-box__question">
                                            <input class="form-check-input question__input" id="q_5_speech" name="q_5_speech" type="checkbox" value="speech problem"> 
                                            <label class="form-check-label question__label" for="q_5_speech">Loss of speech or movement</label>
                                        </div>
                                    </div>
                                    <div class="form-check ps-0 q-box">
                                        <div class="q-box__question">
                                            <input class="form-check-input question__input" id="q_5_pale" name="q_5_pale" type="checkbox" value="pale"> 
                                            <label class="form-check-label question__label" for="q_5_pale">Pale, gray or blue-colored skin, lips or nail beds</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <h4>Provide us with your personal information</h4>
                                <div class="mt-1">
                                    <label class="form-label">Complete Name:</label> 
                                    <input class="form-control" id="full_name" name="full_name" type="text">
                                </div>
                                <div class="mt-2">
                                    <label class="form-label">Complete Address:</label> 
                                    <input class="form-control" id="address" name="address" type="text">
                                </div>
                                <div class="mt-2">
                                    <label class="form-label">Email:</label> 
                                    <input class="form-control" id="email" name="email" type="email">
                                </div>
                                <div class="mt-2">
                                    <label class="form-label">Phone / Mobile Number:</label> 
                                    <input class="form-control" id="phone" name="phone" type="text">
                                </div>
                                <div class="row mt-2">
                                    <div class="col-lg-2 col-md-2 col-3">
                                        <label class="form-label">Age:</label>
                                        <div class="input-container">
                                            <input class="form-control" id="age" name="age" type="text">
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div id="input-container">
                                            <input class="form-check-input" name="gender" type="radio" value="male"> 
                                            <label class="form-check-label radio-lb">Male</label> 
                                            <input class="form-check-input" name="gender" type="radio" value="female"> 
                                            <label class="form-check-label radio-lb">Female</label> 
                                            <input checked class="form-check-input" name="gender" type="radio" value="undefined"> 
                                            <label class="form-check-label radio-lb">Rather not say</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="step">
                                <div class="mt-1">
                                    <div class="closing-text">
                                        <h4>That's about it! Stay healthy!</h4>
                                        <p>We will assess your information and will let you know soon if you need to get tested for COVID-19.</p>
                                        <p>Click on the submit button to continue.</p>
                                    </div>
                                </div>
                            </div>
                            <div id="success">
                                <div class="mt-5">
                                    <h4>Success! We'll get back to you ASAP!</h4>
                                    <p>Meanwhile, clean your hands often, use soap and water, or an alcohol-based hand rub, maintain a safe distance from anyone who is coughing or sneezing and always wear a mask when physical distancing is not possible.</p>
                                    <a class="back-link" href="">Go back from the beginning ➜</a>
                                </div>
                            </div>
                        </div>
                        <div id="q-box__buttons">
                            <button id="prev-btn" type="button">Previous</button> 
                            <button id="next-btn" type="button">Next</button> 
                            <button id="submit-btn" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
            <script>
          const formContainer = document.getElementsByClassName("form-container");
const previousBtn = document.getElementById("previous");
const nextBtn = document.getElementById("next");
const submitBtn = document.getElementById("submit");
const steps = document.getElementsByClassName("steps");
const error = document.getElementById("error-message");
let currentStep = 0;
window.onload = () => {
  currentStep = 0;
  steps[currentStep].classList.add("highlight");
  updateStepVisibility(currentStep);
};
const toggleButtonVisibility = () => {
  previousBtn.classList.toggle("hide", currentStep === 0);
  nextBtn.classList.toggle("hide", currentStep === formContainer.length - 1);
  submitBtn.classList.toggle("hide", currentStep !== formContainer.length - 1);
};
const updateStepVisibility = (stepIndex) => {
  for (let i = 0; i < formContainer.length; i++) {
    formContainer[i].classList.toggle("hide", i !== stepIndex);
  }
  toggleButtonVisibility();
};
nextBtn.addEventListener("click", () => {
  if (currentStep < formContainer.length - 1) currentStep++;
  updateStepVisibility(currentStep);
});
previousBtn.addEventListener("click", () => {
  if (currentStep > 0) currentStep--;
  updateStepVisibility(currentStep);
});

            </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\hotelapp\resources\views/frontend/dashboard/propertyadd.blade.php ENDPATH**/ ?>