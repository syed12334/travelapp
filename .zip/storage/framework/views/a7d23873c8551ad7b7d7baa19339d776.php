<?php
    $step2 = session('step3');
?>
   <form action="<?php echo e(route('step3')); ?>" method="post" id="propertyPhotosVideos" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
   <div class="multistep-box row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 <div class="form-group">
                        <label>Upload gallery photos & videos <span style="color:red">*</span></label>
                        <div class="input-images-1" ></div>
                        <span id="error-photos"></span>
                    </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="form-group">
                    <label>Youtube link </label>
                    <input type="url" name="youtube_link" placeholder="Enter youtube link" >
                    <span id="error-youtube_link"></span>
                </div>
                </div>
                   
                <div class="clearfix"></div>
                             
              <center style="margin-top:10px"> <button type="button" style="margin-right:20px" onclick="return previous(1)">Previous</button> <button type="submit" style="background:orange!important;width:15%">Next</button></center>
            </div>
        </form>

<?php /**PATH D:\laravel\hotelapp\resources\views/frontend/dashboard/property/step3.blade.php ENDPATH**/ ?>