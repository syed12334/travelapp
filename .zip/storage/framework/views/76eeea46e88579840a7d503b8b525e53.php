
<html>
  <head>
    <link href="<?php echo e(asset('app/css/image-uploader.min.css')); ?>" />
    
  </head>
  <body>
     <form method="POST" name="form-example-1" id="form-example-1" enctype="multipart/form-data">

    <div class="input-field">
        <input type="text" name="name-1" id="name-1">
        <label for="name-1">Name</label>
    </div>

    <div class="input-field">
        <input type="text" name="description-1" id="description-1">
        <label for="description-1">Description</label>
    </div>

    <div class="input-field">
        <label class="active">Photos</label>
        <div class="input-images-1" style="padding-top: .5rem;"></div>
    </div>

    <button>Submit and display data</button>

</form>
  </body>
  <script src="<?php echo e(asset('app/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('app/js/image-uploader.min.js')); ?>"></script>
  <script>
 $('.input-images-1').imageUploader({
    imagesInputName: 'photos',
    preloadedInputName: 'old',
    maxSize: 122 * 1024 * 1024,
    maxFiles: 10,
    extensions:['.jpg','.jpeg','.png']
});
  </script>
</html><?php /**PATH D:\laravel\hotelapp\resources\views/frontend/dashboard/property/propertyadd.blade.php ENDPATH**/ ?>