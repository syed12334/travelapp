<?php

namespace App\Http\Controllers\frontend\dashboard;

use App\Models\Property;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\StepthreeValidate;
use App\Services\frontend\dashboard\PropertyService;

class PropertyController extends Controller
{
    public $property;
    public function __construct(PropertyService $pro) {
        $this->property = $pro;
    }
    public function index() {
        return view('frontend.dashboard.property.propertyadd');
    }
    /* Property step1 view */
    public function steponeview() {
       // session()->forget(['step1','step2']);
        return view('frontend.dashboard.property.steponeview');
    }
    /* Property step1 validation */
    public function step1(Request $request) {
       return $this->property->step_one($request->all());
    }
     /* Property step2 view */
    public function steptwoview() {
        return view('frontend.dashboard.property.steptwoview');
    }
     /* Property step2 validation */
    public function step2(Request $request) {
       return $this->property->step_two($request->all());
    }
     /* Property step3 view */
    public function stepthreeview() {
        return view('frontend.dashboard.property.stepthreeview');
    }
    /* Property Step3 validation */
//     public function step3(Request $request) {
//        $files = $request->file('photos');
// $youtube_link = $request->youtube_link;
// $uploadedFiles = [];

//     if ($request->hasFile('photos')) {
//             // foreach ($files as $file) {
//             //     if ($file) {
//             //         $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
//             //         echo $filename."<br />";
//             //         $destination = public_path('gallery');
//             //         $file->move($destination, $filename);

//             //         $fullPath = $destination . '/' . $filename;
//             //         if (file_exists($fullPath)) {
//             //             $uploadedFiles[] = 'uploads/photos/' . $filename; // relative path
//             //         }
//             //     }
//             // }
//                foreach ($request->file('photos') as $file) {
//               //  if ($file && $file->isValid()) {
//                     $path = $file->store('gallery', 'public');
//                     echo $path."<br />";
//                     $uploadedFiles[] = $path;
//                // }
//             }
//         }
//         echo "<pre>";print_r($uploadedFiles);exit;
//        return $this->property->step_three($request);
//     }

    public function step3(Request $request)
{
    $request->validate([
        'youtube_link'   => 'url',
    ]);

    $uploadedFiles = [];


        //if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $file) {
                echo $file->getClientOriginalExtension()."<br />";
              //  if ($file && $file->isValid()) {
                    // $path = $file->store('gallery', 'public');

                    // $uploadedFiles[] = $path;
               // }
            }
       // }
    echo "<pre>";print_r($uploadedFiles);
    
}

   
}

