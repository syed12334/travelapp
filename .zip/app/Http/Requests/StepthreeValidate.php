<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;


class StepthreeValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'photos' => 'required|mimes:jpeg,png,jpg|max:100000',
            'youtube_link'  =>'required|url'

        ];
    }
     public function messages() {
        return [
            'photos.required' =>'Please select atlease one photo or video',
            'photos.mimes'   =>'Only jpeg,png,jpg,mp4 is allowed',
            'youtube_link.url'  =>'Enter valid url',
            'youtube_link.required' =>'Please enter youtube link'
        ];
    }
    protected function failedValidation(Validator $validator)
    {
         throw new HttpResponseException(
        response()->json([
            'status'  => 422,
            'errors'  => $validator->errors()
        ], 422)
    );
    }
}
