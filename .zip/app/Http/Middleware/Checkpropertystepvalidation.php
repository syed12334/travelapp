<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class Checkpropertystepvalidation
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
      public function handle(Request $request, Closure $next, string $requiredStep): Response
    {
        $session = $request->session();

        // If requiredStep is step1, always allow access
        if ($requiredStep === 'step1') {
            return $next($request);
        }

        // For step2, check if step1 data exists
        if ($requiredStep === 'step2' && !$session->has('step1')) {
            return redirect()->route('steponeview');
        }

        // For step3, check if step2 data exists
        if ($requiredStep === 'step3' && !$session->has('step2')) {
            return redirect()->route('steptwoview');
        }

        

        return $next($request);
    }   
}
