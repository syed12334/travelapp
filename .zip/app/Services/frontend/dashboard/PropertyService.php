<?php

namespace App\Services\frontend\dashboard;
use Illuminate\Support\Facades\Validator;
use App\Repositories\frontend\dashboard\PropertyRepository;
class PropertyService
{
    public $property;
    public function __construct(PropertyRepository $proRepo)
    {
        $this->property = $proRepo;
    }
    /* Property step 1 */
    public function step_one($request) {
       $validate =$this->validateProperty($request);
       if ($validate['status'] =="false") {
             $results = [
                'status'  => 422,
                'errors'  => $validate['errors'],
            ];
            return response()->json($results);
        }else {
            session(['step1'=>$request]);
            $response = ['status'=>true];
            return response()->json($response);
        }
    }
     /* Validate property input */
    public function validateProperty($userRequest) {
            $rules['email'] = ['required','email','regex:/(.+)@(.+)\.(.+)/i'];
            $rules['property_name'] =["required","string","max:70"];
            $rules['booking_start_year'] =["required"];
            $rules['property_built_date'] =["required"];
            $rules['property_hosted'] =["required"];
            $rules['host_stay_property'] =["required"];
            $rules['mobile_no'] =["required","integer","min:10"];
            $rules['whatsapp_no'] =["integer","min:10"];
            $rules['landline_no'] =["integer","min:8"];
            /* Custom messages */
            $messages['email.required'] = "Please enter email id";
            $messages['email.regex'] = "Please enter valid emailid";
            $messages['booking_start_year.required'] = "Booking start date is required";
            $messages['property_built_date.required'] = "Property built date is required";
            $messages['property_hosted.required'] = "Host stay property is required";
            $messages['host_stay_property.required'] = "Property name is required";
            /* Mobile No */
            $messages['mobile_no.required'] = "Mobile no is required";
            $messages['mobile_no.max'] = "Mobile no maximum no 12";
            $messages['mobile_no.integer'] = "Mobile no is should be integer";
               /* Landline No */
            $messages['landline_no.required'] = "Landline no is required";
            $messages['landline_no.max'] = "Landline no maximum no 8";
            $messages['landline_no.integer'] = "Landline no is should be integer";
            /* Whatsapp No */
            $messages['whatsapp_no.max'] = "Whatsapp no should be max 12";
            $messages['whatsapp_no.required'] = "Whatsapp no is required";
            $messages['whatsapp_no.integer'] = "Whatsapp no is should be integer";
            $validator = Validator::make($userRequest, $rules,$messages);
            if ($validator->fails()) {
                $result = [
                    'status'  => "false",
                    'errors'  => $validator->errors(),
                ];
                return $result;
            }  
            else {
                $result = [
                    'status'  => "true",
                ];
                return $result;
            }
    }
    /* Property step 2 */
    public function step_two($request) {
       $validate =$this->validatePropertyPersonal($request);
       if ($validate['status'] =="false") {
             $results = [
                'status'  => 422,
                'errors'  => $validate['errors'],
            ];
            return response()->json($results);
        }else {
            session(['step2'=>$request]);
            $response = ['status'=>true];
            return response()->json($response);
        }
    }
     /* Validate property personal input */
    public function validatePropertyPersonal($userRequest) {
            $rules['personal_email'] = ['required','email','regex:/(.+)@(.+)\.(.+)/i'];
            $rules['name_of_host'] =["required","string","max:70"];
            $rules['language_speak'] =["required","string"];
            $rules['hosting_since'] =["required"];
            $rules['total_num_properties'] =["required","integer"];
            $rules['personal_description'] =["required"];
            $rules['personal_mobile_no'] =["required","integer","min:10"];
            $rules['personal_whatsapp_no'] =["integer","min:10"];
            /* Custom messages */
            $messages['email.required'] = "Please enter email id";
            $messages['email.regex'] = "Please enter valid emailid";
            $messages['name_of_host.required'] = "Name of the host is required";
            $messages['language_speak.required'] = "Language is required";
            $messages['hosting_since.required'] = "Hosting since is required";
            $messages['total_num_properties.required'] = "Total property is required";
            /* Mobile No */
            $messages['personal_mobile_no.required'] = "Mobile no is required";
            $messages['personal_mobile_no.max'] = "Mobile no maximum no 12";
            $messages['personal_mobile_no.integer'] = "Mobile no is should be integer";
               /* Landline No */
            $messages['landline_no.max'] = "Landline no maximum no 8";
            $messages['landline_no.integer'] = "Landline no is should be integer";
            /* Whatsapp No */
            $messages['personal_whatsapp_no.max'] = "Whatsapp no should be max 12";
            $messages['personal_whatsapp_no.integer'] = "Whatsapp no is should be integer";
            $validator = Validator::make($userRequest, $rules,$messages);
            if ($validator->fails()) {
                $result = [
                    'status'  => "false",
                    'errors'  => $validator->errors(),
                ];
                return $result;
            }  
            else {
                $result = [
                    'status'  => "true",
                ];
                return $result;
            }
    }

        /* Property step 3 */
    public function step_three($request) {
        echo "<pre>";print_r($request->validated());exit;
       if ($request['errors'] ) {
             $results = [
                'status'  => 422,
                'errors'  => $validate['errors'],
            ];
            return response()->json($results);
        }else {
            session(['step2'=>$request]);
            $response = ['status'=>true];
            return response()->json($response);
        }
    }
}
