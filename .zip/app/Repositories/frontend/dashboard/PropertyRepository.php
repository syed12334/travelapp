<?php

namespace App\Repositories\frontend\dashboard;
use App\Models\Property;

class PropertyRepository
{
    public $property;
    public function __construct(Property $pro)
    {
        $this->property = $pro;
    }
    /* Store property list */
    public function store($property) {
        return $this->property->create($property);
    }
}
