<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\LoginMiddleware;
use App\Http\Controllers\SocialloginController;
use App\Http\Controllers\frontend\HomeController;
use App\Http\Controllers\frontend\UserController;
use App\Http\Controllers\frontend\LoginController;
use App\Http\Controllers\frontend\DashboardController;
use App\Http\Controllers\frontend\dashboard\PropertyController;

/* Front page route */
Route::get('/',[HomeController::class,'index']);
Route::middleware('guest')->group(function() {
    Route::get('register',[UserController::class,'register'])->name('register');
    Route::post('storeuser',[UserController::class,'storeuser'])->name('storeuser');
    Route::get('googleredirect',[UserController::class,'googleLoginRedirect'])->name('googleredirect');
    Route::get('githubredirect',[SocialloginController::class,'github'])->name('githubredirect');
    Route::get('login',[LoginController::class,'index'])->name('login');
    Route::post('loginuser',[LoginController::class,'login'])->name('loginuser');
    Route::get('googleredirectcallback',[UserController::class,'googleredirectcallback'])->name('googleredirectcallback');
    Route::get('githubcallback',[SocialloginController::class,'githubcallback'])->name('githubcallback');
});
Route::get('logout',[UserController::class,'logout'])->name('logout');
/* Dashboard route */
Route::middleware(["authenticate"])->group(function() {
    Route::get('dashboard',[DashboardController::class,'index'])->name('dashboard');
    Route::get('property-add',[PropertyController::class,'index'])->name('property-add');
    Route::post('filepond',[PropertyController::class,'filepond'])->name('filepond');
   
    /* Step 1 route with validation middleware */
    Route::middleware('propertysteps:step1')->group(function() {
         Route::get('steponeview',[PropertyController::class,'steponeview'])->name('steponeview');
        Route::post('step1',[PropertyController::class,'step1'])->name('step1');
    });

    /* Step 2 route with validation middleware */
    Route::middleware('propertysteps:step2')->group(function() {
        Route::get('steptwoview',[PropertyController::class,'steptwoview'])->name('steptwoview');
        Route::post('step2',[PropertyController::class,'step2'])->name('step2');
    });
    
   /* Step 3 route with validation middleware */
    Route::middleware('propertysteps:step3')->group(function() {
        Route::get('stepthreeview',[PropertyController::class,'stepthreeview'])->name('stepthreeview');
        Route::post('step3',[PropertyController::class,'step3'])->name('step3');
    });
    

    
});


