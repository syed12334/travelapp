@extends('layouts.dashboard')

@section('content')
       <main id="main">
                    <section class="profile-dashboard">
                        
                        {{-- <form action="https://themesflat.co/" id="propertyAdd" class="form-add-tour" >
                            @csrf
                           @include('frontend.dashboard.property.step1')

                        </form> --}}

                        <div id="multistep_form">
            <!-- progressbar -->
            <ul id="progress_header">
                        <li ></li>
                        <li class="active"></li>
                        <li></li>
                        <li></li>
                        <li></li>   
                        <li></li> 
                   
              
            </ul>
        
             @include('frontend.dashboard.property.step2')
           
        </div>


                    </section>
                </main>
@endsection

@push('script')
          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
            <script type="text/javascript" src="{{ asset('app/js/property.js'); }}"></script>
                 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
            
<script>
   
/* Dropify js*/
    $('.dropify').dropify();
        $.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
			});

			/* Property data found*/
			$(document).ready(function() {
			  
              /* Property personal details*/
              $("#propertyPersonalDetails").validate({
                rules: {
                    name_of_host:{
                        required: true,
                    },
                     language_speak:{
                        required: true,
                    },
                     hosting_since:{
                        required: true,
                    },
                     total_num_properties:{
                        required: true,
                    },
                     personal_description:{
                        required: true,
                    },
                    // profile_img:{
                    //     required: true,
                    //     extension: "jpg|jpeg|png|gif"
                    // },
                     personal_mobile_no:{
                        required: true,
                    },
                    personal_email: {
                        required: true,
                        email:true
                    },
                    personal_whatsapp_no:{
                        number: true 
                    },
                    landline_no: {
                        number: true 
					} 
                },
                messages: {
                    email: {
                        required: "Please enter email",
                        email:"Please enter valid email"
                    },
                    whatsapp_no:{
                        integer : "Only numbers are allowed"
                    },
                    name_of_host:{
                        required:"Name of host is required"
                    },
                    language_speak : {
                        required:"Language is required"
                    },
                     hosting_since : {
                        required:"Hosting since is required"
                    },
                     total_num_properties : {
                        required:"Total property is required"
                    },
                     personal_description : {
                        required:"Personal description is required"
                    },
                     profile_img : {
                        required:"Profile image is required",
                        extension : "Only jpg,jpeg,png are allowed"
                    },
                     mobile_no : {
                        required:"Mobile no is required",
                        integer : "Only numbers are allowed"
                    },
                     landline_no : {
                        integer : "Only numbers are allowed"
                    }

                },
                submitHandler: function (form) {
                    var formData = new FormData(form);
                    $.ajax({
                        url: form.action,
                        method: form.method,
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (res) {
                            if(res.status == true) {
                                window.location.href="{{ route('stepthreeview')}}";
                            }else if(res.status ==422) {
                                getErrors(res.errors);
                            }
                            else if(res.status =="false") {
                                $("#errorMsg").html('<div class="alert alert-danger" style="top:5%!important">'+res.msg+'</div>');
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            let msg = "Something went wrong!";
                            switch (jqXHR.status) {
                                case 400:
                                    msg = "Bad Request!";
                                    break;
                                case 401:
                                    msg = "Unauthorized! Please log in.";
                                    break;
                                case 403:
                                    msg = "Access denied or token error!";
                                    break;
                                case 404:
                                    msg = "Requested resource not found!";
                                    break;
                                case 419:
                                    msg = "Page expired. Please refresh and try again.";
                                    break;
                                case 422:
                                    msg = "Validation failed!";
                                    break;
                                case 429:
                                    msg = "Too many requests. Login limit exceeded!";
                                    break;
                                case 500:
                                    msg = "Internal Server Error!";
                                    break;
                                case 503:
                                    msg = "Service unavailable. Please try again later.";
                                    break;
                                default:
                                    msg = textStatus + " - " + errorThrown;
                                    break;
                            }
                            $("#errorMsg").html(`<div class="alert alert-danger" style="top:5%!important">${msg}</div>`);
                        }
                    });
                }
            });
		});

        /* Input dynamic values*/
        function getErrors(errors) {
            $.each(errors, function (key, val) {
				$('#error-' + key).text(val[0]);
				$("#"+key).addClass('error');
                
			});
        }

        /* Previous function*/
        function previous(id) {
            $("#step1").show();
            $("#step2").hide();
            $("li").removeClass('active');
            $("li:nth-child("+id+")").addClass('active');
            window.location.href="{{ route('steponeview')}}";
        }
    </script>
@endpush